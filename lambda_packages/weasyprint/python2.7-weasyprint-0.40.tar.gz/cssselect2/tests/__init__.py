# coding: utf8
"""
    cssselect2.tests
    ----------------

    Test suite for cssselect2.

    :copyright: (c) 2012 by Simon Sapin, 2017 by Guillaume Ayoub.
    :license: BSD, see LICENSE for more details.

"""
