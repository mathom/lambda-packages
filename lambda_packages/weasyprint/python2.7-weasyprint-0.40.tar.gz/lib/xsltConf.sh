#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/var/task/lib"
XSLT_LIBS="-lxslt  -L/var/task/lib -lxml2 -lz -lm -ldl -lm "
XSLT_INCLUDEDIR="-I/var/task/include"
MODULE_VERSION="xslt-1.1.29"
